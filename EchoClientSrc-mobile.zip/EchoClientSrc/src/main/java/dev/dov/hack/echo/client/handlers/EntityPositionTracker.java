package dev.dov.hack.echo.client.handlers;

import dev.dov.hack.echo.client.event.Subscribe;
import dev.dov.hack.echo.client.event.lifecycle.ClientTickEvent;
import dev.dov.hack.echo.client.event.network.PacketReceiveEvent;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundBundlePacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public final class EntityPositionTracker extends ClientHandler {
    private static final int MAX_HISTORY_SAMPLES = 8;
    private static final int UNCHANGED_POSITION_SAMPLE_TICKS = 3;
    private static final Map<Integer, ArrayDeque<PositionSample>> positionHistory = new HashMap<>();
    private static final Map<Integer, VelocitySample> velocitySamples = new HashMap<>();
    private static final ConcurrentLinkedQueue<ClientboundSetEntityMotionPacket> receivedVelocityPackets =
            new ConcurrentLinkedQueue<>();
    private static Object trackedWorld;
    private static int trackerTick;

    
    public static int currentTick() {
        return trackerTick;
    }

    
    public static List<PositionSample> positions(Entity entity) {
        ArrayDeque<PositionSample> history = positionHistory.get(entity.getId());
        return history == null ? List.of() : List.copyOf(history);
    }

    
    public static VelocitySample velocity(Entity entity) {
        return velocitySamples.get(entity.getId());
    }

    @Subscribe
    private void onPacketReceived(PacketReceiveEvent event) {
        Packet<?> packet = event.getPacket();
        if (packet instanceof ClientboundBundlePacket bundle) {
            for (Packet<?> bundled : bundle.subPackets()) {
                if (bundled instanceof ClientboundSetEntityMotionPacket velocity) {
                    receivedVelocityPackets.add(velocity);
                }
            }
        } else if (event.getPacket() instanceof ClientboundSetEntityMotionPacket velocity) {
            receivedVelocityPackets.add(velocity);
        }
    }

    @Subscribe
    private void onTick(ClientTickEvent event) {
        if (CLIENT.level == null || CLIENT.player == null) {
            positionHistory.clear();
            velocitySamples.clear();
            receivedVelocityPackets.clear();
            trackedWorld = null;
            return;
        }
        if (trackedWorld != CLIENT.level) {
            positionHistory.clear();
            velocitySamples.clear();
            trackedWorld = CLIENT.level;
        }
        trackerTick++;
        ClientboundSetEntityMotionPacket packet;
        while ((packet = receivedVelocityPackets.poll()) != null) {
            Entity entity = CLIENT.level.getEntity(packet.getId());
            if (entity instanceof Player player && player != CLIENT.player) {
                velocitySamples.put(player.getId(), new VelocitySample(
                        trackerTick, player.getPositionCodec().getBase(), packet.getMovement()));
            }
        }

        Set<Integer> presentPlayers = new HashSet<>();
        for (Player player : CLIENT.level.players()) {
            if (player == CLIENT.player) {
                continue;
            }
            presentPlayers.add(player.getId());
            Vec3 position = player.getPositionCodec().getBase();
            ArrayDeque<PositionSample> history = positionHistory.computeIfAbsent(
                    player.getId(), ignored -> new ArrayDeque<>());
            PositionSample previous = history.peekLast();
            if (previous != null && previous.position().equals(position)
                    && trackerTick - previous.tick() < UNCHANGED_POSITION_SAMPLE_TICKS) {
                continue;
            }
            history.addLast(new PositionSample(trackerTick, position, player.onGround()));
            if (history.size() > MAX_HISTORY_SAMPLES) {
                history.removeFirst();
            }
        }
        positionHistory.keySet().retainAll(presentPlayers);
        velocitySamples.keySet().retainAll(presentPlayers);
    }
}
