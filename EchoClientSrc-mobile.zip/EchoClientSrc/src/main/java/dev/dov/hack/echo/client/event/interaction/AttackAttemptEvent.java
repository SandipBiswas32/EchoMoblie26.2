package dev.dov.hack.echo.client.event.interaction;

import dev.dov.hack.echo.client.event.Event;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public class AttackAttemptEvent extends Event {
    private final Player player;
    private final Entity target;

    
    public AttackAttemptEvent(Player player, Entity target) {
        this.player = player;
        this.target = target;
    }

    
    public Player getPlayer() { return player; }

    
    public Entity getTarget() { return target; }
}
