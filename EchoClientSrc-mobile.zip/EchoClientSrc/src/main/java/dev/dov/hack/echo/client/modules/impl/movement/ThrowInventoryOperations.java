package dev.dov.hack.echo.client.modules.impl.movement;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

public final class ThrowInventoryOperations {
    private ThrowInventoryOperations() {
    }

    
    public static void swapHands(Minecraft client) {
        ItemStack previousOffhand = client.player.getItemInHand(InteractionHand.OFF_HAND);
        client.player.connection.send(new ServerboundPlayerActionPacket(
                ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ZERO, Direction.DOWN));
        client.player.setItemInHand(InteractionHand.OFF_HAND, client.player.getItemInHand(InteractionHand.MAIN_HAND));
        client.player.setItemInHand(InteractionHand.MAIN_HAND, previousOffhand);
    }
}
