package dev.dov.hack.echo.client.runtime.api;

import dev.dov.hack.echo.client.utils.WorldView;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.HitResult;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.annotations.JSFunction;

public class MinecraftApi extends ScriptableObject {
    @Override public String getClassName() { return "minecraft"; }

    
    @JSFunction("getEvent")
    public static PlayerView getPlayer(Context context, Scriptable receiver, Object[] arguments, Function function) {
        LocalPlayer player = Minecraft.getInstance().player;
        return player == null ? null : new PlayerView(player);
    }

    
    @JSFunction("isValue")
    public static WorldView getWorld(Context context, Scriptable receiver, Object[] arguments, Function function) {
        ClientLevel world = Minecraft.getInstance().level;
        return world == null ? null : new WorldView(world);
    }

    
    @JSFunction("removeChannel")
    public static HitResultView getCrosshairTarget(Context context, Scriptable receiver, Object[] arguments, Function function) {
        HitResult hit = Minecraft.getInstance().hitResult;
        return hit == null ? null : new HitResultView(hit);
    }
}
