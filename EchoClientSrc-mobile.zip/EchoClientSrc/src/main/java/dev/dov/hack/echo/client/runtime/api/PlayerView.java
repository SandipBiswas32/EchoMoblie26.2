package dev.dov.hack.echo.client.runtime.api;

import dev.dov.hack.echo.client.utils.items.PlayerInventoryView;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class PlayerView extends EntityView {
    private final Player player;

    
    public PlayerView(Player player) {
        super(player);
        this.player = player;
    }

    
    public Vector3View getVelocity() { return new Vector3View(player.getDeltaMovement()); }

    
    public boolean isOnGround() { return player.onGround(); }

    
    public float getHealth() { return player.getHealth(); }

    
    public boolean isSprinting() { return player.isSprinting(); }

    
    public boolean isUsingItem() { return player.isUsingItem(); }

    
    public boolean isTouchingWater() { return player.isInWater(); }

    
    public boolean isDead() { return player.isDeadOrDying(); }

    
    public boolean isGliding() { return player.isFallFlying(); }

    
    public boolean isCreative() { return player.isCreative(); }

    
    public boolean isSneaking() { return player.isShiftKeyDown(); }

    
    public float getAttackCooldownProgress() { return player.getAttackStrengthScale(0.5F); }

    
    public double getBlockInteractionRange() { return player.blockInteractionRange(); }

    
    public PlayerInventoryView getInventory() { return new PlayerInventoryView(player.getInventory()); }

    
    public void swingHand(String hand) { player.swing(parseHand(hand)); }

    
    public void setRotation(float yaw, float pitch) {
        player.setYRot(yaw);
        player.setXRot(pitch);
    }

    
    public void setSprinting(boolean sprinting) { player.setSprinting(sprinting); }

    
    public void setSelectedSlot(int slot) { player.getInventory().setSelectedSlot(slot); }

    
    public void setVelocity(double x, double y, double z) { player.setDeltaMovement(new Vec3(x, y, z)); }

    
    public void clearActiveItem() { player.stopUsingItem(); }

    
    public void interactMainHand() {
        Minecraft client = Minecraft.getInstance();
        if (client.gameMode == null) return;
        client.gameMode.useItem(player, InteractionHand.MAIN_HAND);
    }

    
    public void attack(EntityView target) {
        Minecraft client = Minecraft.getInstance();
        if (client.gameMode == null) return;
        client.gameMode.attack(player, target.entity);
    }

    private InteractionHand parseHand(String hand) {
        return "off".equalsIgnoreCase(hand) ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
    }
}
