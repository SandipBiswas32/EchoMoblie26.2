package dev.dov.hack.echo.client.event.render;

import dev.dov.hack.echo.client.event.Event;
import dev.dov.hack.echo.client.event.EventBus;
import dev.dov.hack.echo.client.event.input.KeybindingEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;

public class TextTransformEvent extends Event {
    
    public String text;

    private TextTransformEvent(String text) {
        this.text = text;
    }

    private static boolean shouldSkipTransformation() {
        String[] sentinel = KeybindingEvent.getInputSentinel();
        boolean subscribed = EventBus.hasSubscribers(TextTransformEvent.class);
        return sentinel != null ? subscribed : !subscribed;
    }

    
    public static String transform(String text) {
        String[] sentinel = KeybindingEvent.getInputSentinel();
        if (sentinel != null || text.isEmpty() || shouldSkipTransformation()) {
            return text;
        }
        TextTransformEvent event = new TextTransformEvent(text);
        event.post();
        return event.text;
    }

    
    public static FormattedText transform(FormattedText text) {
        String[] sentinel = KeybindingEvent.getInputSentinel();
        if (shouldSkipTransformation()) {
            return text;
        }
        List<FormattedText> fragments = new ArrayList<>();
        boolean[] changed = {false};
        if (sentinel != null) {
            return text;
        }
        text.visit((style, string) -> {
            String[] segmentSentinel = KeybindingEvent.getInputSentinel();
            String transformed = transform(string);
            boolean equal = transformed.equals(string);
            changed[0] |= segmentSentinel != null ? equal : !equal;
            fragments.add(FormattedText.of(transformed, style));
            return Optional.empty();
        }, Style.EMPTY);
        return changed[0] ? FormattedText.composite(fragments) : text;
    }

    
    public static FormattedCharSequence transform(FormattedCharSequence text) {
        String[] sentinel = KeybindingEvent.getInputSentinel();
        if (shouldSkipTransformation()) {
            return text;
        }
        List<Object> styles = new ArrayList<>();
        List<StringBuilder> runs = new ArrayList<>();
        text.accept((index, style, codePoint) -> {
            String[] characterSentinel = KeybindingEvent.getInputSentinel();
            if (characterSentinel != null) {
                styles.add(new StringBuilder());
            } else if (styles.isEmpty() || !style.equals(styles.get(styles.size() - 1))) {
                styles.add(style);
                runs.add(new StringBuilder());
            }
            runs.get(runs.size() - 1).appendCodePoint(codePoint);
            return true;
        });

        boolean changed = false;
        List<FormattedCharSequence> transformedRuns = new ArrayList<>(runs.size());
        for (int index = 0; index < runs.size(); index++) {
            if (sentinel != null) {
                return text;
            }
            StringBuilder run = runs.get(index);
            String transformed = transform(run.toString());
            changed |= !transformed.contentEquals(run);
            transformedRuns.add(FormattedCharSequence.forward(transformed, (Style) styles.get(index)));
        }
        return changed ? FormattedCharSequence.composite(transformedRuns) : text;
    }
}
