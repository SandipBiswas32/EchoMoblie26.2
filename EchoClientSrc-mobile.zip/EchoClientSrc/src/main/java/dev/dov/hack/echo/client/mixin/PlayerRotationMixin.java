package dev.dov.hack.echo.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.MinecraftAccess;
import dev.dov.hack.echo.client.event.movement.RotationContext;
import dev.dov.hack.echo.client.event.movement.RotationEvent;
import dev.dov.hack.echo.client.modules.impl.movement.KeepSprint;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Player.class)
public abstract class PlayerRotationMixin {
    @ModifyExpressionValue(method = "aiStep", at = @At(
        value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;getYRot()F", ordinal = 0))
    private float modifyTickMovementAtGetYawAtOrdinal0(float yaw) {
        if ((Object) this != MinecraftAccess.CLIENT.player) {
            return yaw;
        }
        return RotationEvent.dispatch(RotationContext.HEAD, yaw, MinecraftAccess.CLIENT.player.getXRot()).getYaw();
    }

    @Redirect(method = {"causeExtraKnockback", "doSweepAttack"}, at = @At(
        value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;getYRot()F"))
    private float redirectKnockbackTargetAtGetYaw(Player player) {
        return player != MinecraftAccess.CLIENT.player ? player.getYRot()
            : RotationEvent.dispatch(RotationContext.ATTACK, player.getYRot(), player.getXRot()).getYaw();
    }

    @Redirect(method = "causeExtraKnockback", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/phys/Vec3;multiply(DDD)Lnet/minecraft/world/phys/Vec3;"))
    private Vec3 redirectKnockbackTargetAtMultiply(Vec3 velocity, double x, double y, double z) {
        if (!EchoClient.eventsDisabled && (Object) this == MinecraftAccess.CLIENT.player
                && EchoClient.ModuleManager != null) {
            KeepSprint keepSprint = (KeepSprint) EchoClient.ModuleManager.findFeature(KeepSprint.class);
            if (keepSprint != null && keepSprint.isEnabled()) {
                float multiplier = KeepSprint.speedKeptVelocity.getValue();
                return velocity.multiply(multiplier, y, multiplier);
            }
        }
        return velocity.multiply(x, y, z);
    }

    @Redirect(method = "causeExtraKnockback", at = @At(
        value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;setSprinting(Z)V"))
    private void redirectKnockbackTargetAtSetSprinting(Player player, boolean sprinting) {
        if (!EchoClient.eventsDisabled && EchoClient.ModuleManager != null) {
            KeepSprint keepSprint = (KeepSprint) EchoClient.ModuleManager.findFeature(KeepSprint.class);
            if (keepSprint != null && keepSprint.isEnabled() && keepSprint.shouldKeepSprinting()) {
                return;
            }
        }
        player.setSprinting(sprinting);
    }
}
