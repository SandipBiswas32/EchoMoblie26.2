package dev.dov.hack.echo.client.modules.impl.utility;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class ElytraSwapItems {
    private ElytraSwapItems() {}

    public static boolean isElytra(ItemStack stack) {
        return stack.getItem() == Items.ELYTRA;
    }
}
