package dev.dov.hack.echo.client.modules.impl.world;

import dev.dov.hack.echo.client.init.CatalogSettings;
import dev.dov.hack.echo.client.init.CatalogText;
import dev.dov.hack.echo.client.event.Subscribe;
import dev.dov.hack.echo.client.event.input.AttackKeyEvent;
import dev.dov.hack.echo.client.event.input.MouseMovementEvent;
import dev.dov.hack.echo.client.event.input.PlayerInputEvent;
import dev.dov.hack.echo.client.event.interaction.BlockBreakingEvent;
import dev.dov.hack.echo.client.event.lifecycle.ClientTickEvent;
import dev.dov.hack.echo.client.modules.ModuleCategory;
import dev.dov.hack.echo.client.modules.Module;
import dev.dov.hack.echo.client.modules.ModuleInfo;
import dev.dov.hack.echo.client.handlers.rotation.AimTransition;
import dev.dov.hack.echo.client.handlers.rotation.RotationPriority;
import dev.dov.hack.echo.client.handlers.rotation.RotationSettings;
import dev.dov.hack.echo.client.handlers.rotation.RotationVisibility;
import dev.dov.hack.echo.client.settings.BooleanSetting;
import dev.dov.hack.echo.client.settings.ChoiceSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class Tunneler extends Module {
    private static final CharSequence SINGLE_BLOCK = CatalogText.literal("1x1");
    private static ChoiceSetting mode;
    private static BooleanSetting silent;
    private boolean breakingBlock;
    private boolean targetUpperBlock;
    private boolean aimingAtBlock;

    public Tunneler() {
        super(new ModuleInfo(CatalogText.literal("Tunneler"), CatalogText.literal("Automatically mines tunnels while walking forward"), ModuleCategory.WORLD, false));
    }

    public static void appendBootstrapSettings(Tunneler Module) {
        CatalogSettings.append(Module, mode);
        CatalogSettings.append(Module, silent);
    }

    public static void assignBootstrapSettings(Tunneler Module, BooleanSetting preparedSilent, ChoiceSetting preparedMode) {
        silent = preparedSilent;
        mode = preparedMode;
    }

    @Override
    public void postInitialize() {
        breakingBlock = false;
        targetUpperBlock = true;
        aimingAtBlock = false;
        super.postInitialize();
    }

    @Subscribe
    private void onTick(ClientTickEvent event) {
        if (isOutsideWorld()) return;
        if (client.hitResult instanceof BlockHitResult hit) {
            BlockPos position = hit.getBlockPos();
            var side = hit.getDirection();
            if (client.level.getBlockState(position).isAir()) {
                breakingBlock = false;
                return;
            }
            if (client.gameMode != null) {
                if (client.gameMode.continueDestroyBlock(position, side)) {
                    client.player.swing(InteractionHand.MAIN_HAND);
                    breakingBlock = true;
                } else {
                    breakingBlock = false;
                }
            }
        }
    }

    @Subscribe
    private void onPlayerInput(PlayerInputEvent event) {
        if (isOutsideWorld()) return;
        event.forward = true;
        event.backward = false;
        event.left = false;
        event.right = false;
        event.jump = false;
        event.sneak = false;
        event.allowMovementInFreecam = true;
    }

    @Subscribe
    private void onMouseMovement(MouseMovementEvent.Post event) {
        if (isOutsideWorld()) return;
        Vec3 target = findTarget();
        if (target == null) {
            if (aimingAtBlock && rotations().isAiming() && rotations().isOwnedBy(this)) {
                if (!rotations().beginReturn(this)) aimingAtBlock = false;
            } else if (rotations().isOwnedBy(this)) {
                rotations().cancel(this);
                aimingAtBlock = false;
            }
            return;
        }
        var manager = rotations();
        RotationSettings settings = RotationSettings.uniform(
                silent.getValue() ? RotationVisibility.SILENT : RotationVisibility.VISIBLE, AimTransition.EASED, 100.0F);
        if (manager.aim(this, RotationPriority.HIGH, target, settings)) aimingAtBlock = true;
    }

    private Vec3 findTarget() {
        if (client.player == null || client.level == null) return null;
        float yaw = client.player.getYRot();
        double radians = Math.toRadians(yaw);
        double forwardX = -Math.sin(radians);
        double forwardZ = Math.cos(radians);
        Vec3 playerPosition = client.player.position();
        int y = (int) Math.floor(playerPosition.y);
        double x = playerPosition.x + forwardX;
        double z = playerPosition.z + forwardZ;
        if (mode.isSelected(SINGLE_BLOCK)) {
            BlockPos block = new BlockPos((int) Math.floor(x), y, (int) Math.floor(z));
            return client.level.getBlockState(block).isAir() ? null : Vec3.atCenterOf(block);
        }
        BlockPos lower = new BlockPos((int) Math.floor(x), y, (int) Math.floor(z));
        BlockPos upper = new BlockPos((int) Math.floor(x), y + 1, (int) Math.floor(z));
        boolean upperSolid = !client.level.getBlockState(upper).isAir();
        boolean lowerSolid = !client.level.getBlockState(lower).isAir();
        if (!upperSolid && !lowerSolid) return null;
        if (upperSolid && !lowerSolid) {
            targetUpperBlock = true;
        } else if (!upperSolid && lowerSolid) {
            targetUpperBlock = false;
        } else if (!breakingBlock) {
            targetUpperBlock = !targetUpperBlock;
        }
        return Vec3.atCenterOf(targetUpperBlock ? upper : lower);
    }

    @Subscribe
    private void onAttackKey(AttackKeyEvent event) {
        if (isOutsideWorld()) return;
        event.cancel();
    }

    @Subscribe
    private void onBlockBreaking(BlockBreakingEvent.Pre event) {
        event.cancel();
    }

    @Override
    public void onDisable() {
        if (rotations().isOwnedBy(this)) rotations().cancel(this);
        aimingAtBlock = false;
        breakingBlock = false;
        targetUpperBlock = true;
        super.onDisable();
    }
}
