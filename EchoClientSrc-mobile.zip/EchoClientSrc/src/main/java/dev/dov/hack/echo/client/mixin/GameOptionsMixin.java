package dev.dov.hack.echo.client.mixin;

import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.event.render.PerspectiveEvent;
import net.minecraft.client.CameraType;
import net.minecraft.client.Options;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Options.class)
public class GameOptionsMixin {
    @Inject(method = "setCameraType", at = @At("HEAD"), cancellable = true)
    private void onSetPerspectiveHead(CameraType perspective, CallbackInfo callback) {
        if (!EchoClient.eventsDisabled) {
            PerspectiveEvent event = new PerspectiveEvent(perspective);
            event.post();
            if (event.cancelled) {
                callback.cancel();
            }
        }
    }
}
