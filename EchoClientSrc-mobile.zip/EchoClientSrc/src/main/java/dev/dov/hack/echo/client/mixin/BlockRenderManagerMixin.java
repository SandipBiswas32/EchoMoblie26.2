package dev.dov.hack.echo.client.mixin;

import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.event.EventBus;
import dev.dov.hack.echo.client.event.render.FluidRenderEvent;
import dev.jadyen.hack.echo.natives.SodiumBridge;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BlockRenderDispatcher.class)
public class BlockRenderManagerMixin {
    @Inject(method = "renderLiquid", at = @At("HEAD"), cancellable = true)
    public void onRenderFluidHead(BlockPos position, BlockAndTintGetter world, VertexConsumer vertices, BlockState blockState, FluidState fluidState, CallbackInfo callback) {
        if (!EchoClient.eventsDisabled && !SodiumBridge.isLoaded()
                && EventBus.hasSubscribers(FluidRenderEvent.class)) {
            if (new FluidRenderEvent().post()) {
                callback.cancel();
            }
        }
    }
}
