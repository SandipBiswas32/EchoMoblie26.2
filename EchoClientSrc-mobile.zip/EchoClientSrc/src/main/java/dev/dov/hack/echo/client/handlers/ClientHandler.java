package dev.dov.hack.echo.client.handlers;

import dev.dov.hack.echo.client.MinecraftAccess;
import net.minecraft.client.Minecraft;

public class ClientHandler implements MinecraftAccess {
    protected static final Minecraft CLIENT = Minecraft.getInstance();
}
