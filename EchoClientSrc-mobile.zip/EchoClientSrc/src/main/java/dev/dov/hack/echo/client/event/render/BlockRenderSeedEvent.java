package dev.dov.hack.echo.client.event.render;

import dev.dov.hack.echo.client.event.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

public class BlockRenderSeedEvent extends Event {
    
    public final BlockState state;
    
    public final BlockPos position;

    
    public BlockRenderSeedEvent(BlockState state, BlockPos position) {
        this.state = state;
        this.position = position;
    }
}
