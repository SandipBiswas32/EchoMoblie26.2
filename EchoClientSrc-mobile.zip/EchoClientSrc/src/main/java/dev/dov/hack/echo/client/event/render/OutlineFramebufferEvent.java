package dev.dov.hack.echo.client.event.render;

import com.mojang.blaze3d.pipeline.RenderTarget;
import dev.dov.hack.echo.client.event.Event;
import dev.dov.hack.echo.client.event.EventPhase;

public class OutlineFramebufferEvent extends Event {
    private final RenderTarget framebuffer;
    private final boolean canDrawEntityOutlines;

    private OutlineFramebufferEvent(EventPhase phase, RenderTarget framebuffer, boolean canDrawEntityOutlines) {
        super(phase);
        this.framebuffer = framebuffer;
        this.canDrawEntityOutlines = canDrawEntityOutlines;
    }

    public RenderTarget getFramebuffer() {
        return framebuffer;
    }

    public boolean canDrawEntityOutlines() {
        return canDrawEntityOutlines;
    }

    
    public static class Prepare extends OutlineFramebufferEvent {
        public Prepare(RenderTarget framebuffer, boolean canDrawEntityOutlines) {
            super(EventPhase.POST, framebuffer, canDrawEntityOutlines);
        }
    }

    
    public static class Render extends OutlineFramebufferEvent {
        public Render() {
            super(EventPhase.PRE, null, false);
        }
    }
}
