package dev.dov.hack.echo.client.event.world;

import dev.dov.hack.echo.client.event.Event;
import java.lang.invoke.MethodHandles;
import net.minecraft.world.level.chunk.LevelChunk;

public class ChunkLoadEvent extends Event {
    private final LevelChunk chunk;

    
    public ChunkLoadEvent(LevelChunk chunk) {
        super();
        this.chunk = chunk;
    }

    
    public LevelChunk getChunk() {
        try {
            MethodHandles.lookup().ensureInitialized(LevelChunk.class);
        } catch (IllegalAccessException inaccessibleType) {
            throw new IllegalAccessError(inaccessibleType.getMessage());
        }
        return chunk;
    }
}
