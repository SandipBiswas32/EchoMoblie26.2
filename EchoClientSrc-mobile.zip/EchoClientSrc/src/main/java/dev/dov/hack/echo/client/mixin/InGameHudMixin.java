package dev.dov.hack.echo.client.mixin;

import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.event.render.InGameHudEvent;
import dev.dov.hack.echo.client.event.render.NauseaOverlayEvent;
import dev.dov.hack.echo.client.event.render.PortalOverlayEvent;
import dev.dov.hack.echo.client.event.render.SpyglassOverlayEvent;
import dev.dov.hack.echo.client.event.render.VignetteOverlayEvent;
import dev.dov.hack.echo.client.modules.impl.render.Hotbar;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Gui.class)
public abstract class InGameHudMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void onRenderHead(GuiGraphics context, DeltaTracker tickCounter, CallbackInfo callback) {
        if (!EchoClient.eventsDisabled) {
            InGameHudEvent event = new InGameHudEvent();
            event.post();
            if (event.cancelled) {
                callback.cancel();
            }
        }
    }

    @Inject(method = "renderItemHotbar", at = @At("HEAD"), cancellable = true)
    public void onRenderHotbarHead(GuiGraphics context, DeltaTracker tickCounter, CallbackInfo callback) {
        if (!EchoClient.eventsDisabled && Hotbar.replacesVanillaHotbar()) {
            callback.cancel();
        }
    }

    @Inject(method = "renderVignette", at = @At("HEAD"), cancellable = true)
    public void onRenderVignetteOverlayHead(GuiGraphics context, Entity entity, CallbackInfo callback) {
        if (!EchoClient.eventsDisabled) {
            VignetteOverlayEvent event = new VignetteOverlayEvent();
            event.post();
            if (event.cancelled) {
                callback.cancel();
            }
        }
    }

    @Inject(method = "renderConfusionOverlay", at = @At("HEAD"), cancellable = true)
    public void onRenderNauseaOverlayHead(GuiGraphics context, float strength, CallbackInfo callback) {
        if (!EchoClient.eventsDisabled) {
            NauseaOverlayEvent event = new NauseaOverlayEvent();
            event.post();
            if (event.cancelled) {
                callback.cancel();
            }
        }
    }

    @Inject(method = "renderSpyglassOverlay", at = @At("HEAD"), cancellable = true)
    public void onRenderSpyglassOverlayHead(GuiGraphics context, float scale, CallbackInfo callback) {
        if (!EchoClient.eventsDisabled) {
            SpyglassOverlayEvent event = new SpyglassOverlayEvent();
            event.post();
            if (event.cancelled) {
                callback.cancel();
            }
        }
    }

    @Inject(method = "renderPortalOverlay", at = @At("HEAD"), cancellable = true)
    public void onRenderPortalOverlayHead(GuiGraphics context, float strength, CallbackInfo callback) {
        if (!EchoClient.eventsDisabled) {
            PortalOverlayEvent event = new PortalOverlayEvent();
            event.post();
            if (event.cancelled) {
                callback.cancel();
            }
        }
    }
}
