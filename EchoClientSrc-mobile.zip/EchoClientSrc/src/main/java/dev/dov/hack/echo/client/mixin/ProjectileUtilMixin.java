package dev.dov.hack.echo.client.mixin;

import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.event.world.EntityHitboxEvent;
import dev.dov.hack.echo.client.modules.impl.utility.AntiTrap;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ProjectileUtil.class)
public class ProjectileUtilMixin {
    @Redirect(method = "getEntityHitResult(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/AABB;Ljava/util/function/Predicate;D)Lnet/minecraft/world/phys/EntityHitResult;", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getBoundingBox()Lnet/minecraft/world/phys/AABB;"))
    private static AABB redirectRaycastAtGetBoundingBox(Entity entity) {
        AABB targetingBox = entity.getBoundingBox().inflate(entity.getPickRadius());
        if (EchoClient.eventsDisabled) {
            return targetingBox;
        }
        if (AntiTrap.shouldIgnoreEntity(entity)) {
            double excludedY = entity.getY() - 1024.0;
            return new AABB(entity.getX(), excludedY, entity.getZ(), entity.getX(), excludedY, entity.getZ());
        }
        EntityHitboxEvent event = new EntityHitboxEvent(entity, targetingBox);
        event.post();
        return event.getBoundingBox();
    }
}
