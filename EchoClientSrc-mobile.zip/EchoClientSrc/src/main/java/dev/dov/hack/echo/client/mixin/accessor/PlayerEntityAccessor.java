package dev.dov.hack.echo.client.mixin.accessor;

import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(Player.class)
public interface PlayerEntityAccessor {
    @Invoker("canFallAtLeast")
    boolean invokeIsSpaceAroundPlayerEmpty(double offsetX, double offsetY, double offsetZ);
}
