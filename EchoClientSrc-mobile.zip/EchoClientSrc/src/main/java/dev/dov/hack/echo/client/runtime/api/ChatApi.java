package dev.dov.hack.echo.client.runtime.api;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.annotations.JSFunction;

public class ChatApi extends ScriptableObject {
    
    @Override
    public String getClassName() { return "chat"; }

    
    @JSFunction("writeEvent")
    public static void print(Context context, Scriptable receiver, Object[] arguments, Function function) {
        if (arguments.length == 0) return;
        Component message = Component.literal(Context.toString(arguments[0]));
        Minecraft client = Minecraft.getInstance();
        if (client.gui == null) return;
        client.gui.getChat().addMessage(message);
    }
}
