package dev.dov.hack.echo.client.gui.panels;

import net.minecraft.client.multiplayer.PlayerInfo;

final class FriendRow {
    final String playerName;
    final PlayerInfo playerEntry;
    boolean friend;

    FriendRow(String playerName, PlayerInfo playerEntry, boolean friend) {
        this.playerName = playerName;
        this.playerEntry = playerEntry;
        this.friend = friend;
    }
}
