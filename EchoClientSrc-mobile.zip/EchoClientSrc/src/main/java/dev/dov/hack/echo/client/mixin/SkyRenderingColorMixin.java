package dev.dov.hack.echo.client.mixin;

import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.MinecraftAccess;
import dev.dov.hack.echo.client.modules.impl.render.Ambience;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.SkyRenderer;
import net.minecraft.client.renderer.state.SkyRenderState;
import net.minecraft.util.ARGB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SkyRenderer.class)
public class SkyRenderingColorMixin {
    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void onUpdateRenderStateTail(ClientLevel world, float tickProgress, Camera camera, SkyRenderState state, CallbackInfo callback) {
        if (!EchoClient.eventsDisabled && MinecraftAccess.CLIENT.player != null && MinecraftAccess.CLIENT.level != null
                && EchoClient.ModuleManager != null) {
            Ambience ambience = (Ambience) EchoClient.ModuleManager.findFeature(Ambience.class);
            if (ambience != null && ambience.isEnabled() && Ambience.isFogColorEnabled()) {
                state.skyColor = ARGB.color(Ambience.getFogRed(), Ambience.getFogGreen(), Ambience.getFogBlue());
                if (Ambience.isGradientEnabled()) {
                    state.sunriseAndSunsetColor = ARGB.color(255, Ambience.getGradientRed(), Ambience.getGradientGreen(), Ambience.getGradientBlue());
                } else {
                    state.sunriseAndSunsetColor = 0;
                }
                state.shouldRenderDarkDisc = false;
            }
        }
    }
}
