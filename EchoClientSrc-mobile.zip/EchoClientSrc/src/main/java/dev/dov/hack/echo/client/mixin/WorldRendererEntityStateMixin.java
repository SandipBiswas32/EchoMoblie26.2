package dev.dov.hack.echo.client.mixin;

import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.MinecraftAccess;
import dev.dov.hack.echo.client.modules.impl.render.Freecam;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.state.LevelRenderState;
import net.minecraft.world.TickRateManager;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelRenderer.class)
public abstract class WorldRendererEntityStateMixin {
    @Shadow
    protected abstract EntityRenderState extractEntity(Entity entity, float tickProgress);

    @Inject(method = "extractVisibleEntities", at = @At("RETURN"))
    private void onFillEntityRenderStatesReturn(Camera camera, Frustum frustum, DeltaTracker ticks, LevelRenderState state, CallbackInfo callback) {
        if (MinecraftAccess.CLIENT.player != null && MinecraftAccess.CLIENT.level != null
                && !EchoClient.eventsDisabled && EchoClient.ModuleManager != null) {
            Freecam freecam = (Freecam) EchoClient.ModuleManager.findFeature(Freecam.class);
            if (freecam.isEnabled()) {
                LocalPlayer player = MinecraftAccess.CLIENT.player;
                TickRateManager tickManager = MinecraftAccess.CLIENT.level.tickRateManager();
                float tickProgress = ticks.getGameTimeDeltaPartialTick(!tickManager.isEntityFrozen(player));
                EntityRenderState playerState = extractEntity(player, tickProgress);
                state.entityRenderStates.add(playerState);
            }
        }
    }
}
