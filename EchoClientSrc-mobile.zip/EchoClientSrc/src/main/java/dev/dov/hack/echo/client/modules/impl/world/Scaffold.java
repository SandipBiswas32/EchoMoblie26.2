package dev.dov.hack.echo.client.modules.impl.world;

import dev.dov.hack.echo.client.init.CatalogSettings;
import dev.dov.hack.echo.client.init.CatalogText;
import dev.dov.hack.echo.client.event.Subscribe;
import dev.dov.hack.echo.client.event.input.HotbarKeyEvent;
import dev.dov.hack.echo.client.event.input.MouseMovementEvent;
import dev.dov.hack.echo.client.event.input.PlayerInputEvent;
import dev.dov.hack.echo.client.event.input.UseKeyEvent;
import dev.dov.hack.echo.client.event.interaction.BlockInteractEvent;
import dev.dov.hack.echo.client.event.movement.MovementPacketEvent;
import dev.dov.hack.echo.client.modules.ModuleCategory;
import dev.dov.hack.echo.client.modules.Module;
import dev.dov.hack.echo.client.modules.ModuleInfo;
import dev.dov.hack.echo.client.handlers.DeferredActionQueue;
import dev.dov.hack.echo.client.handlers.rotation.RotationManager;
import dev.dov.hack.echo.client.settings.BooleanSetting;
import dev.dov.hack.echo.client.settings.ChoiceSetting;
import dev.dov.hack.echo.client.settings.RegistryListSetting;
import dev.dov.hack.echo.client.settings.specialized.ScaffoldBlockListSetting;
import dev.dov.hack.echo.client.utils.placement.ScaffoldController;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;

public class Scaffold extends Module {
    private static final CharSequence modeOption = CatalogText.literal("Legit");
    private static final CharSequence listTypeOption = CatalogText.literal("Whitelist");
    private static final CharSequence listTypeOption2 = CatalogText.literal("Blacklist");
    private static ChoiceSetting mode;
    private static BooleanSetting pitchCheck;
    private static ChoiceSetting listType;
    private static RegistryListSetting<Block> blocks =
        new ScaffoldBlockListSetting(CatalogText.literal("Blocks Selection"), () -> BuiltInRegistries.BLOCK);
    private ScaffoldController scaffoldController;
    private static String conditionsSection;
    private static String listTypeSection;
    private static String blocksSection;

    public Scaffold() {
        super(new ModuleInfo(CatalogText.literal("Scaffold"), CatalogText.literal("Module to assist with bridging"), ModuleCategory.WORLD));
    }

    @Override
    public void postInitialize() {
        scaffoldController = new ScaffoldController(this, new Predicate<Object>() {
            @Override public boolean test(Object ignored) { return mode.isSelected(modeOption); }
        });
        pitchCheck.description(CatalogText.literal("Only assist while looking down"));
        blocks.description(CatalogText.literal("Blocks the list applies to. An empty whitelist allows every block"));
        if (conditionsSection == null) conditionsSection = "Conditions";
        pitchCheck.tooltip(conditionsSection);
        if (listTypeSection == null) listTypeSection = "Blocks";
        listType.tooltip(listTypeSection);
        if (blocksSection == null) blocksSection = "Blocks";
        blocks.tooltip(blocksSection);
        settings.addAll(scaffoldController.getSettings());
    }

    @Override
    public boolean requiresMovementCorrection() {
        return true;
    }

    @Override
    public CharSequence getSuffix() {
        return mode.getValue();
    }

    public static boolean passesPitchCheck() {
        return !pitchCheck.getValue() || client.player.getXRot() > 0.0f;
    }

    public static boolean isAllowedStack(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return false;
        }
        if (!isSuitableBlock(blockItem.getBlock())) {
            return false;
        }
        boolean selected = blocks.isEntrySelected(blockItem.getBlock());
        if (listType.isSelected(listTypeOption2)) {
            return !selected;
        }
        return blocks.getSelectedCount() == 0 || selected;
    }

    public static boolean isSuitableBlock(Block block) {
        if (block instanceof FallingBlock) {
            return false;
        }
        BlockState state = block.defaultBlockState();
        if (state.getCollisionShape(EmptyBlockGetter.INSTANCE, BlockPos.ZERO).isEmpty()) {
            return false;
        }
        VoxelShape outline = state.getShape(EmptyBlockGetter.INSTANCE, BlockPos.ZERO);
        return Block.isFaceFull(outline, Direction.DOWN)
            && outline.max(Direction.Axis.Y) >= 0.75;
    }

    @Override
    public void onEnable() {
        try {
            Class.forName(ScaffoldController.class.getName(), true, ScaffoldController.class.getClassLoader());
        } catch (ClassNotFoundException failure) {
            throw new IllegalStateException("Resolved class initialization failed", failure);
        }
        ScaffoldController controller = scaffoldController;
        try {
            Class.forName(ScaffoldController.class.getName(), true, ScaffoldController.class.getClassLoader());
        } catch (ClassNotFoundException failure) {
            throw new IllegalStateException("Resolved class initialization failed", failure);
        }
        controller.reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        DeferredActionQueue.finish(this, false);
        try {
            Class.forName(RotationManager.class.getName(), true, RotationManager.class.getClassLoader());
        } catch (ClassNotFoundException failure) {
            throw new IllegalStateException("Resolved class initialization failed", failure);
        }
        RotationManager rotations = rotations();
        try {
            Class.forName(RotationManager.class.getName(), true, RotationManager.class.getClassLoader());
        } catch (ClassNotFoundException failure) {
            throw new IllegalStateException("Resolved class initialization failed", failure);
        }
        rotations.release(this);
        super.onDisable();
    }

    @Subscribe
    private void onPlayerInput(PlayerInputEvent event) {
        if (mode.isSelected(modeOption)) scaffoldController.onPlayerInput(event);
    }

    @Subscribe
    private void onMovementPacket(MovementPacketEvent.Post event) {
        if (mode.isSelected(modeOption)) scaffoldController.onMovementPacket(event);
    }

    @Subscribe
    private void onMouseMovement(MouseMovementEvent.Post event) {
        if (mode.isSelected(modeOption)) scaffoldController.onMouseMovement(event);
    }

    @Subscribe
    private void onHotbarKey(HotbarKeyEvent event) {
        if (mode.isSelected(modeOption)) scaffoldController.onHotbarKey(event);
    }

    @Subscribe
    private void onUseKey(UseKeyEvent event) {
        if (mode.isSelected(modeOption)) scaffoldController.onUseKey(event);
    }

    @Subscribe
    private void onBlockInteract(BlockInteractEvent.Post event) {
        if (mode.isSelected(modeOption)) scaffoldController.onBlockInteract(event);
    }

    public static void appendBootstrapSettings(Scaffold Module) {
        CatalogSettings.append(Module, mode);
        CatalogSettings.append(Module, pitchCheck);
        CatalogSettings.append(Module, listType);
        CatalogSettings.append(Module, blocks);
    }

    public static CharSequence bootstrapModeOption() { return modeOption; }
    public static CharSequence bootstrapListTypeOption() { return listTypeOption; }
    public static CharSequence bootstrapListTypeOption2() { return listTypeOption2; }

    public static void assignBootstrapSettings(Scaffold Module, BooleanSetting preparedPitchCheck, ChoiceSetting preparedMode, ChoiceSetting preparedListType) {
        pitchCheck = preparedPitchCheck;
        mode = preparedMode;
        listType = preparedListType;
    }
}
