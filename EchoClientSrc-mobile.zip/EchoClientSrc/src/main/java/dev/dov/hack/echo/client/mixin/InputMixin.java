package dev.dov.hack.echo.client.mixin;

import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.modules.impl.movement.Sprint;
import net.minecraft.client.player.ClientInput;
import net.minecraft.world.phys.Vec2;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientInput.class)
public class InputMixin {
    @Shadow protected Vec2 moveVector;

    @Inject(method = "hasForwardImpulse", at = @At("HEAD"), cancellable = true)
    private void allowOmnidirectionalSprint(CallbackInfoReturnable<Boolean> callback) {
        if (EchoClient.eventsDisabled) {
            return;
        }
        if (EchoClient.ModuleManager != null) {
            Sprint sprint = (Sprint) EchoClient.ModuleManager.findFeature(Sprint.class);
            if (sprint != null && sprint.isOmniEnabled()) {
                callback.setReturnValue(moveVector.lengthSquared() > 1.0E-5F);
            }
        }
    }
}
