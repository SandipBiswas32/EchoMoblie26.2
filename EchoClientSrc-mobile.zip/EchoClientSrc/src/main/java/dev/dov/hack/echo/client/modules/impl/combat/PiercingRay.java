package dev.dov.hack.echo.client.modules.impl.combat;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

public record PiercingRay(LocalPlayer player, Vec3 start, Vec3 end) {
}
