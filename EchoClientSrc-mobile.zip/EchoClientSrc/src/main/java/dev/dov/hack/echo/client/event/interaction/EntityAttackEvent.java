package dev.dov.hack.echo.client.event.interaction;

import dev.dov.hack.echo.client.event.Event;
import dev.dov.hack.echo.client.event.EventPhase;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public class EntityAttackEvent extends Event {
    private final Player player;
    private final Entity target;
    private static String[] attackSentinel;

    static {
        if (getAttackSentinel() != null) {
            setAttackSentinel(new String[5]);
        }
    }

    
    public EntityAttackEvent(EventPhase phase, Player player, Entity target) {
        super(phase);
        this.player = player;
        this.target = target;
    }

    
    public Player getPlayer() {
        return player;
    }

    
    public Entity getTarget() {
        return target;
    }

    
    public static void setAttackSentinel(String[] sentinel) {
        attackSentinel = sentinel;
    }

    
    public static String[] getAttackSentinel() {
        return attackSentinel;
    }

    
    public static class Pre extends EntityAttackEvent {
        
        public Pre(Player player, Entity target) {
            super(EventPhase.PRE, player, target);
        }
    }

    
    public static class Post extends EntityAttackEvent {
        
        public Post(Player player, Entity target) {
            super(EventPhase.POST, player, target);
        }
    }
}
