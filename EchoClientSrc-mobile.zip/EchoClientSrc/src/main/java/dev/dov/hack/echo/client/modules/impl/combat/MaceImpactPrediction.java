package dev.dov.hack.echo.client.modules.impl.combat;

import net.minecraft.world.entity.LivingEntity;

public record MaceImpactPrediction(LivingEntity target, int impactTick) {
}
