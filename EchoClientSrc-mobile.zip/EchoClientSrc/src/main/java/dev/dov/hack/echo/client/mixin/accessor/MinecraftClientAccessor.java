package dev.dov.hack.echo.client.mixin.accessor;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {
    @Invoker("doItemUse")
    void invokeDoItemUse();

    @Accessor("itemUseCooldown")
    void setItemUseCooldown(int ticks);
}
