package dev.dov.hack.echo.client.modules.impl.combat;

import dev.dov.hack.echo.client.init.CatalogSettings;
import dev.dov.hack.echo.client.init.CatalogText;
import dev.dov.hack.echo.client.event.Subscribe;
import dev.dov.hack.echo.client.event.lifecycle.FrameStartEvent;
import dev.dov.hack.echo.client.modules.ModuleCategory;
import dev.dov.hack.echo.client.modules.Module;
import dev.dov.hack.echo.client.modules.ModuleInfo;
import dev.dov.hack.echo.client.mixin.accessor.KeyBindingAccessor;
import dev.dov.hack.echo.client.render.bridge.MinecraftRenderState;
import dev.dov.hack.echo.client.settings.BooleanSetting;
import dev.dov.hack.echo.client.settings.ChoiceSetting;
import dev.dov.hack.echo.client.settings.FloatRangeSetting;
import dev.dov.hack.echo.client.settings.HotbarSlotsSetting;
import dev.dov.hack.echo.client.settings.ItemListSetting;
import dev.dov.hack.echo.client.utils.CooldownTimer;
import dev.dov.hack.echo.client.utils.MathRng;

public class AutoClicker extends Module {
    private static final CharSequence randomizationOption2 = CatalogText.literal("None");
    private static final CharSequence randomizationOption = CatalogText.literal("Normal");
    private static FloatRangeSetting cps;
    private static ChoiceSetting randomization;
    private static ItemListSetting itemWhitelist;
    private static HotbarSlotsSetting hotbarWhitelist;
    private static BooleanSetting requireClick;
    private static BooleanSetting breakBlocks;
    private CooldownTimer clickRateTimer;
    private CooldownTimer burstTimer;
    private int burstClickCount;
    private long nextClickMillis;
    private double intervalScale;
    private double currentClicksPerSecond;
    private double targetClicksPerSecond;
    private long nextRateChangeMillis;
    private double previousIntervalMillis;
    private int similarIntervalCount;

    public AutoClicker() {
        super(new ModuleInfo(CatalogText.literal("Auto Clicker"), CatalogText.literal("Clicks the attack button for you"), ModuleCategory.COMBAT, false));
    }

    
    public static void appendBootstrapSettings(AutoClicker Module) {
        CatalogSettings.append(Module, cps);
        CatalogSettings.append(Module, randomization);
        CatalogSettings.append(Module, itemWhitelist);
        CatalogSettings.append(Module, hotbarWhitelist);
        CatalogSettings.append(Module, requireClick);
        CatalogSettings.append(Module, breakBlocks);
    }

    public static CharSequence bootstrapRandomizationOption() { return randomizationOption; }
    public static CharSequence bootstrapRandomizationOption2() { return randomizationOption2; }

    public static void assignBootstrapSettings(AutoClicker Module, HotbarSlotsSetting preparedHotbarWhitelist, BooleanSetting preparedBreakBlocks, ItemListSetting preparedItemWhitelist, BooleanSetting preparedRequireClick, FloatRangeSetting preparedCps, ChoiceSetting preparedRandomization) {
        hotbarWhitelist = preparedHotbarWhitelist;
        breakBlocks = preparedBreakBlocks;
        itemWhitelist = preparedItemWhitelist;
        requireClick = preparedRequireClick;
        cps = preparedCps;
        randomization = preparedRandomization;
    }

    @Override
    public void postInitialize() {
        clickRateTimer = new CooldownTimer();
        burstTimer = new CooldownTimer();
        intervalScale = 0.85;
        cps.setAllowOutOfRange(true);
        requireClick.description(CatalogText.literal("Only click while the attack button is held"));
        breakBlocks.description(CatalogText.literal("Keep clicking while breaking a block"));
        randomization.description(CatalogText.literal("None clicks at a fixed rate in the middle of the CPS range"));
        cps.tooltip(CatalogText.literal("Timing"));
        randomization.tooltip(CatalogText.literal("Timing"));
        itemWhitelist.tooltip(CatalogText.literal("Conditions"));
        hotbarWhitelist.tooltip(CatalogText.literal("Conditions"));
    }

    
    @Override
    public void onEnable() {
        super.onEnable();
        try {
            Class.forName(CooldownTimer.class.getName(), true, CooldownTimer.class.getClassLoader());
        } catch (ClassNotFoundException failure) {
            throw new IllegalStateException("Resolved class initialization failed", failure);
        }
        java.util.Objects.requireNonNull(clickRateTimer, "object reference is null").reset();
        try {
            Class.forName(FloatRangeSetting.class.getName(), true, FloatRangeSetting.class.getClassLoader());
        } catch (ClassNotFoundException failure) {
            throw new IllegalStateException("Resolved class initialization failed", failure);
        }
        float initialRate = java.util.Objects.requireNonNull(cps, "object reference is null").sampleGaussian();
        targetClicksPerSecond = initialRate;
        currentClicksPerSecond = initialRate;
        nextRateChangeMillis = 0L;
        nextClickMillis = 0L;
        try {
            Class.forName(CooldownTimer.class.getName(), true, CooldownTimer.class.getClassLoader());
        } catch (ClassNotFoundException failure) {
            throw new IllegalStateException("Resolved class initialization failed", failure);
        }
        java.util.Objects.requireNonNull(burstTimer, "object reference is null").reset();
        burstClickCount = 0;
    }
    @Subscribe
    private void onFrameStart(FrameStartEvent event) {
        long now = System.nanoTime() / 1_000_000L;
        if (shouldSuppressClick()) {
            nextClickMillis = Math.max(nextClickMillis, now);
            return;
        }
        if (now < nextClickMillis) return;
        client.missTime = 0;
        KeyBindingAccessor attack = (KeyBindingAccessor) client.options.keyAttack;
        attack.setTimesPressed(attack.getTimesPressed() + 1);
        nextClickMillis = Math.max(nextClickMillis, now - 40L) + computeClickIntervalMillis();
    }

    private boolean shouldSuppressClick() {
        return isOutsideWorld() || MinecraftRenderState.getScreen() != null
                || client.player.isUsingItem() || client.gameMode == null
                || (!breakBlocks.getValue() && client.gameMode.isDestroying())
                || (requireClick.getValue() && !client.options.keyAttack.isDown())
                || !itemWhitelist.acceptsHeldItem() || !hotbarWhitelist.permitsCurrentSlot();
    }

    private long computeClickIntervalMillis() {
        if (randomization.isSelected(randomizationOption2)) {
            return (long) (2000.0 / (cps.getLower() + cps.getUpper()));
        }
        if (clickRateTimer.hasElapsedMillis((double) nextRateChangeMillis)) {
            targetClicksPerSecond = cps.sampleGaussian();
            nextRateChangeMillis = (long) (2500.0 + MathRng.random.nextDouble() * 3500.0);
            clickRateTimer.reset();
        }
        currentClicksPerSecond += (targetClicksPerSecond - currentClicksPerSecond) * 0.05;
        currentClicksPerSecond = Math.max(cps.getLower(), Math.min(cps.getUpper(), currentClicksPerSecond));
        double nominalInterval = 1000.0 / currentClicksPerSecond;
        double scaledInterval = nominalInterval * intervalScale;
        double interval = scaledInterval + MathRng.random.nextGaussian() * scaledInterval * 0.2
                - Math.log(1.0 - MathRng.random.nextDouble()) * scaledInterval * 0.1;
        if (MathRng.random.nextDouble() < 0.04) {
            interval += 140.0 + MathRng.random.nextDouble() * 260.0;
        }
        interval = Math.max(scaledInterval * 0.55, interval);
        double similarityThreshold = scaledInterval * 0.3;
        if (Math.abs(interval - previousIntervalMillis) < similarityThreshold && ++similarIntervalCount >= 5) {
            interval += 60.0 + MathRng.random.nextDouble() * 100.0;
            similarIntervalCount = 0;
        } else if (Math.abs(interval - previousIntervalMillis) >= similarityThreshold) {
            similarIntervalCount = 0;
        }
        previousIntervalMillis = interval;
        intervalScale = Math.max(0.5, Math.min(1.1, intervalScale + (nominalInterval - interval) / nominalInterval * 0.03));
        return (long) interval;
    }
}
