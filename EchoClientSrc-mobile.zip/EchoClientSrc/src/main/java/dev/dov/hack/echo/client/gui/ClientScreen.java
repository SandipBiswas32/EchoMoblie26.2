package dev.dov.hack.echo.client.gui;

import dev.dov.hack.echo.client.render.ui.GuiDimensions;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public abstract class ClientScreen extends Screen {
    
    protected ClientScreen(Component title) {
        super(title);
    }

    
    @Override
    public void renderBackground(GuiGraphics context, int mouseX, int mouseY, float tickDelta) {
    }

    
    @Override
    public void renderTransparentBackground(GuiGraphics context) {
    }

    
    public float toUiX(float x) {
        return x * GuiDimensions.width()
                / Minecraft.getInstance().getWindow().getGuiScaledWidth();
    }

    
    public float toUiY(float y) {
        return y * GuiDimensions.height()
                / Minecraft.getInstance().getWindow().getGuiScaledHeight();
    }
}
