package dev.dov.hack.echo.client.event.render;

import dev.dov.hack.echo.client.event.Event;
import net.minecraft.client.CameraType;

public class PerspectiveEvent extends Event {
    private final CameraType perspective;

    public PerspectiveEvent(CameraType perspective) {
        this.perspective = perspective;
    }

    public CameraType getPerspective() {
        return perspective;
    }
}
