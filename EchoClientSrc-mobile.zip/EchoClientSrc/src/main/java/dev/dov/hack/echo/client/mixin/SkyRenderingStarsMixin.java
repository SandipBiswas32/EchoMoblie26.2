package dev.dov.hack.echo.client.mixin;

import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.modules.impl.render.SkyShaders;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SkyRenderer;
import dev.dov.hack.echo.client.gfx.FullscreenEffects;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SkyRenderer.class)
public class SkyRenderingStarsMixin {
    @Unique
    private static boolean echo$hasCustomSky() {
        if (EchoClient.eventsDisabled) {
            return false;
        }
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null || EchoClient.ModuleManager == null) {
            return false;
        }
        SkyShaders sky = (SkyShaders) EchoClient.ModuleManager.findFeature(SkyShaders.class);
        return sky != null && sky.isEnabled();
    }

    @Inject(method = "renderSkyDisc", at = @At("HEAD"), cancellable = true)
    private void replaceTopSky(int color, CallbackInfo callback) {
        if (echo$hasCustomSky() && FullscreenEffects.renderCustomSky()) {
            callback.cancel();
        }
    }

    @Inject(method = "renderEndSky", at = @At("HEAD"), cancellable = true)
    private void replaceEndSky(CallbackInfo callback) {
        if (echo$hasCustomSky() && SkyShaders.shouldRenderInEnd() && FullscreenEffects.renderCustomSky()) {
            callback.cancel();
        }
    }

    @Inject(method = "renderSunriseAndSunset", at = @At("HEAD"), cancellable = true)
    private void suppressGlowingSky(CallbackInfo callback) {
        if (echo$hasCustomSky()) {
            callback.cancel();
        }
    }

    @Inject(method = "renderSunMoonAndStars", at = @At("HEAD"), cancellable = true)
    private void controlCelestialBodies(CallbackInfo callback) {
        if (echo$hasCustomSky() && !SkyShaders.shouldRenderSunAndMoon()) {
            callback.cancel();
        }
    }

    @Inject(method = "renderEndFlash", at = @At("HEAD"), cancellable = true)
    private void suppressEndLightFlash(CallbackInfo callback) {
        if (echo$hasCustomSky() && SkyShaders.shouldRenderInEnd()) {
            callback.cancel();
        }
    }
}
