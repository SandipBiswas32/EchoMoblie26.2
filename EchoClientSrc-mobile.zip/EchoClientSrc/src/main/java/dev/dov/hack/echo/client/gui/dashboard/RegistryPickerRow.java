package dev.dov.hack.echo.client.gui.dashboard;

import net.minecraft.resources.Identifier;

public record RegistryPickerRow(Identifier id, String label) {
}
