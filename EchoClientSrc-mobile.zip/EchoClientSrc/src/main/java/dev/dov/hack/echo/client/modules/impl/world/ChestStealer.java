package dev.dov.hack.echo.client.modules.impl.world;

import dev.dov.hack.echo.client.event.Subscribe;
import dev.dov.hack.echo.client.event.lifecycle.ClientTickEvent;
import dev.dov.hack.echo.client.modules.Module;
import dev.dov.hack.echo.client.modules.ModuleInfo;
import dev.dov.hack.echo.client.settings.BooleanSetting;
import dev.dov.hack.echo.client.settings.IntSetting;
import dev.dov.hack.echo.client.utils.StopwatchTimer;
import dev.dov.hack.echo.client.utils.inventory.SlotAction;
import dev.dov.hack.echo.client.utils.inventory.SlotPackets;
import dev.dov.hack.echo.client.utils.items.InventoryItems;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.EnderpearlItem;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PotionItem;

public class ChestStealer extends Module {
    public static IntSetting initialDelay;
    public static IntSetting takeDelay;
    public static IntSetting closeDelay;
    public static BooleanSetting onlyImportant;
    private dev.dov.hack.echo.client.utils.StopwatchTimer openDelayTimer;
    private dev.dov.hack.echo.client.utils.StopwatchTimer transferDelayTimer;
    private dev.dov.hack.echo.client.utils.StopwatchTimer closeDelayTimer;
    private boolean hasTransferredItems;

    public ChestStealer() {
        super(new ModuleInfo(dev.dov.hack.echo.client.init.CatalogText.literal("Chest Stealer"), dev.dov.hack.echo.client.init.CatalogText.literal("Automatically loots chests"), dev.dov.hack.echo.client.modules.ModuleCategory.WORLD));
    }

    @Override
    public void postInitialize() {
        openDelayTimer = new StopwatchTimer();
        transferDelayTimer = new StopwatchTimer();
        closeDelayTimer = new StopwatchTimer();
        hasTransferredItems = false;
        initialDelay.tooltip("Timing");
        takeDelay.tooltip("Timing");
        closeDelay.tooltip("Timing");
    }

    @Subscribe
    public void onClientTick(ClientTickEvent event) {
        if (client.player == null || client.level == null) {
            return;
        }
        if (!isEnabled()) {
            return;
        }
        AbstractContainerMenu currentHandler = client.player.containerMenu;
        if (!(currentHandler instanceof ChestMenu container)) {
            openDelayTimer.reset();
            transferDelayTimer.reset();
            closeDelayTimer.reset();
            hasTransferredItems = false;
            return;
        }
        if (!openDelayTimer.hasElapsedMillis(initialDelay.getValue())) {
            transferDelayTimer.reset();
            return;
        }
        if (hasNoEligibleItems(container)) {
            if (hasTransferredItems && closeDelayTimer.hasElapsedMillis(closeDelay.getValue())) {
                client.player.closeContainer();
            }
            return;
        }

        int containerSize = container.getContainer().getContainerSize();
        for (int slotIndex = 0; slotIndex < containerSize; slotIndex++) {
            Slot slot = container.getSlot(slotIndex);
            if (!slot.hasItem()) {
                continue;
            }
            ItemStack stack = slot.getItem();
            if (!isEligibleItem(stack)) {
                continue;
            }
            if (!transferDelayTimer.hasElapsedMillis(takeDelay.getValue())) {
                continue;
            }
            SlotPackets.clickSlot(client.player.containerMenu.containerId, slotIndex, 0, SlotAction.QUICK_MOVE, client.player);
            hasTransferredItems = true;
            transferDelayTimer.reset();
            closeDelayTimer.reset();
        }
    }

    public boolean hasNoEligibleItems(ChestMenu container) {
        int containerSize = container.getContainer().getContainerSize();
        for (int slotIndex = 0; slotIndex < containerSize; slotIndex++) {
            Slot slot = container.getSlot(slotIndex);
            if (slot.hasItem() && isEligibleItem(slot.getItem())) {
                return false;
            }
        }
        return true;
    }

    private boolean isEligibleItem(ItemStack stack) {
        if (!onlyImportant.getValue()) {
            return true;
        }
        return InventoryItems.isAxe(stack)
                || stack.has(DataComponents.FOOD)
                || stack.getItem() instanceof BlockItem
                || InventoryItems.isLegacySword(stack.getItem())
                || stack.has(DataComponents.WEAPON)
                || stack.has(DataComponents.TOOL)
                || stack.has(DataComponents.EQUIPPABLE)
                || stack.getItem() instanceof EnderpearlItem
                || stack.getItem() instanceof BowItem
                || stack.getItem() instanceof ArrowItem
                || stack.getItem() instanceof FishingRodItem
                || stack.getItem() instanceof PotionItem;
    }

    @Override
    public void onDisable() {
        openDelayTimer.reset();
        transferDelayTimer.reset();
        closeDelayTimer.reset();
        hasTransferredItems = false;
        super.onDisable();
    }

}
