package dev.dov.hack.echo.client.mixin;
import dev.dov.hack.echo.client.platform.Platform;

import java.util.List;
import net.minecraft.client.gui.render.state.GuiRenderState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiRenderState.class)
public class GuiRenderStateMixin implements Platform.GuiState {
    @Shadow @Final private List<?> strata;
    @Shadow private int firstStratumAfterBlur;
    @Unique private int screenLayerStart = -1;
    @Unique private boolean screenBlurLayerInstalled;

    @Inject(method = "reset", at = @At("TAIL"))
    private void onClearTail(CallbackInfo callback) {
        screenLayerStart = -1;
        screenBlurLayerInstalled = false;
    }

    @Override
    public void markScreenLayerStart() {
        if (screenLayerStart == -1) {
            screenLayerStart = strata.size();
        }
    }

    @Override
    public boolean prepareScreenBlurLayer() {
        if (screenLayerStart == -1 || screenLayerStart >= strata.size()) {
            return false;
        }
        if (firstStratumAfterBlur == Integer.MAX_VALUE) {
            firstStratumAfterBlur = screenLayerStart;
            screenBlurLayerInstalled = true;
        }
        return true;
    }

    @Override
    public boolean isScreenBlurLayerInstalled() {
        return screenBlurLayerInstalled;
    }
}
