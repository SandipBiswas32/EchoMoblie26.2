package dev.dov.hack.echo.client.event.render;

import dev.dov.hack.echo.client.event.Event;
import dev.dov.hack.echo.client.event.EventBus;
import java.util.UUID;
import net.minecraft.world.entity.player.PlayerSkin;

public class SkinTexturesEvent extends Event {
    
    public final UUID playerId;
    
    public PlayerSkin textures;

    private SkinTexturesEvent(UUID playerId, PlayerSkin textures) {
        this.playerId = playerId;
        this.textures = textures;
    }

    
    public static PlayerSkin resolve(UUID playerId, PlayerSkin textures) {
        if (!EventBus.hasSubscribers(SkinTexturesEvent.class)) {
            return textures;
        }
        SkinTexturesEvent event = new SkinTexturesEvent(playerId, textures);
        event.post();
        return event.textures;
    }
}
