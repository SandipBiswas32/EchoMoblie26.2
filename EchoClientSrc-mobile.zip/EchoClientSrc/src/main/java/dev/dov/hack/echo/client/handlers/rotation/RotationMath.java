package dev.dov.hack.echo.client.handlers.rotation;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class RotationMath {
    private RotationMath() {
    }

    
    public static float smoothVelocity(float velocity, float angularError, float speed, float elapsedSeconds) {
        float speedLimit = speed * Math.min(1.0F + Math.abs(angularError) / 30.0F, 3.0F);
        float desiredVelocity = Mth.clamp(angularError * speed, -speedLimit, speedLimit);
        float blend = 1.0F - (float) Math.exp(-elapsedSeconds * 15.0F);
        return Mth.clamp(velocity + (desiredVelocity - velocity) * blend, -speedLimit, speedLimit);
    }

    
    public static Vec3 randomPoint(AABB box) {
        ThreadLocalRandom random = ThreadLocalRandom.current();
        return new Vec3(
                box.minX + random.nextDouble() * (box.maxX - box.minX), box.minY + random.nextDouble() * (box.maxY - box.minY), box.minZ + random.nextDouble() * (box.maxZ - box.minZ));
    }
}
