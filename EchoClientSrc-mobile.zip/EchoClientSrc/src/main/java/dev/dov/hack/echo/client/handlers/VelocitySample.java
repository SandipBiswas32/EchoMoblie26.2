package dev.dov.hack.echo.client.handlers;

import net.minecraft.world.phys.Vec3;

public record VelocitySample(int tick, Vec3 position, Vec3 velocity) {
}
