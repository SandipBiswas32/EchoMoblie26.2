package dev.dov.hack.echo.client.modules.impl.combat;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

public record PiercingTarget(LivingEntity entity, Vec3 hitPosition) {
    
    public EntityHitResult toHitResult() {
        return new EntityHitResult(entity, hitPosition);
    }
}
