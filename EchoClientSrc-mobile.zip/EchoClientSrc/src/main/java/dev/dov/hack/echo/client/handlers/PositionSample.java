package dev.dov.hack.echo.client.handlers;

import net.minecraft.world.phys.Vec3;

public record PositionSample(int tick, Vec3 position, boolean onGround) {
}
