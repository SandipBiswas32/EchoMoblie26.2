package dev.dov.hack.echo.client.event.render;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.dov.hack.echo.client.event.Event;
import dev.dov.hack.echo.client.render.bridge.DrawContextAdapter;
import dev.dov.hack.echo.client.render.ui.UiRenderer;
import net.minecraft.client.Minecraft;
import dev.dov.hack.echo.client.gfx.texture.TextureView;
import org.joml.Matrix4f;

public class HudRenderEvent extends Event {
    private PoseStack matrices;
    private float tickDelta;
    private DrawContextAdapter drawContext;
    private UiRenderer renderer;
    private TextureView texture;

    
    public HudRenderEvent(PoseStack matrices, float tickDelta, DrawContextAdapter drawContext, UiRenderer renderer, TextureView texture) {
        this.matrices = matrices;
        this.tickDelta = tickDelta;
        this.drawContext = drawContext;
        this.renderer = renderer;
        this.texture = texture;
    }

    
    public int getWidth() {
        return (int) Math.ceil(Minecraft.getInstance().getWindow().getWidth() / 2.0);
    }

    
    public Matrix4f createIdentityMatrix() { return new Matrix4f(); }

    
    public int getHeight() {
        return (int) Math.ceil(Minecraft.getInstance().getWindow().getHeight() / 2.0);
    }

    
    public PoseStack getMatrices() { return matrices; }

    
    public float getTickDelta() { return tickDelta; }

    
    public DrawContextAdapter getDrawContext() { return drawContext; }

    
    public UiRenderer getRenderer() { return renderer; }

    
    public TextureView getTexture() { return texture; }
}
