package dev.dov.hack.echo.client.modules.impl.world;

import dev.dov.hack.echo.client.init.CatalogSettings;
import dev.dov.hack.echo.client.init.CatalogText;
import dev.dov.hack.echo.client.event.Subscribe;
import dev.dov.hack.echo.client.event.input.HandleInputEvent;
import dev.dov.hack.echo.client.modules.ModuleCategory;
import dev.dov.hack.echo.client.modules.Module;
import dev.dov.hack.echo.client.modules.ModuleInfo;
import dev.dov.hack.echo.client.settings.BooleanSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.phys.BlockHitResult;

public class AutoTool extends Module {
    private static BooleanSetting switchBack;
    private static BooleanSetting requireClick;
    private static BooleanSetting requireShift;
    private int previousSlot;

    public AutoTool() {
        super(new ModuleInfo(CatalogText.literal("Auto Tool"), CatalogText.literal("Automatically selects best tool"), ModuleCategory.WORLD));
    }

    @Override
    public void postInitialize() {
        previousSlot = -1;
        super.postInitialize();
    }

    @Subscribe
    public void onHandleInput(HandleInputEvent.Pre event) {
        if (isOutsideWorld()) {
            return;
        }
        if (client.hitResult instanceof BlockHitResult hit
                && !client.level.getBlockState(hit.getBlockPos()).isAir()
                && (!requireClick.getValue() || client.options.keyAttack.isDown())
                && (!requireShift.getValue() || client.options.keyShift.isDown())) {
            int bestSlot = findBestToolSlot(hit.getBlockPos());
            if (bestSlot != -1) {
                if (previousSlot == -1) {
                    previousSlot = client.player.getInventory().getSelectedSlot();
                }
                client.player.getInventory().setSelectedSlot(bestSlot);
            } else if (switchBack.getValue() && previousSlot != -1) {
                client.player.getInventory().setSelectedSlot(previousSlot);
                previousSlot = -1;
            }
        } else if (switchBack.getValue() && previousSlot != -1) {
            client.player.getInventory().setSelectedSlot(previousSlot);
            previousSlot = -1;
        }
    }

    private int findBestToolSlot(BlockPos position) {
        int bestSlot = -1;
        float bestSpeed = 1.0f;
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = client.player.getInventory().getItem(slot);
            if (stack.isEmpty()) {
                continue;
            }
            float speed = miningSpeed(stack, position);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = slot;
            }
        }
        return bestSlot;
    }

    private float miningSpeed(ItemStack stack, BlockPos position) {
        if (stack.isEmpty()) {
            return 0.0f;
        }
        float speed = stack.getDestroySpeed(client.level.getBlockState(position));
        if (speed > 1.0f) {
            var efficiency = client.level.registryAccess().get(Enchantments.EFFICIENCY);
            if (efficiency.isPresent()) {
                int level = EnchantmentHelper.getItemEnchantmentLevel(efficiency.get(), stack);
                if (level > 0) {
                    speed += level * level + 1;
                }
            }
        }
        return speed;
    }

    public static void appendBootstrapSettings(AutoTool Module) {
        CatalogSettings.append(Module, switchBack);
        CatalogSettings.append(Module, requireClick);
        CatalogSettings.append(Module, requireShift);
    }

    public static void assignBootstrapSettings(AutoTool Module, BooleanSetting preparedRequireClick, BooleanSetting preparedSwitchBack, BooleanSetting preparedRequireShift) {
        requireClick = preparedRequireClick;
        switchBack = preparedSwitchBack;
        requireShift = preparedRequireShift;
    }
}
