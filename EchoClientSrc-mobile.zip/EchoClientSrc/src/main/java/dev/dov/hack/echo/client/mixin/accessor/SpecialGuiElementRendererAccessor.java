package dev.dov.hack.echo.client.mixin.accessor;

import com.mojang.blaze3d.textures.GpuTextureView;
import net.minecraft.client.gui.render.pip.PictureInPictureRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(PictureInPictureRenderer.class)
public interface SpecialGuiElementRendererAccessor {
    @Accessor("textureView")
    GpuTextureView getTextureView();
}
