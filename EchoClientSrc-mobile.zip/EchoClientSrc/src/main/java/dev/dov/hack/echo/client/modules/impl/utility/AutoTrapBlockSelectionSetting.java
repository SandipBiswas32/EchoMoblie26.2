package dev.dov.hack.echo.client.modules.impl.utility;

import dev.dov.hack.echo.client.settings.ChoiceSetting;
import dev.dov.hack.echo.client.settings.RegistryListSetting;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

public final class AutoTrapBlockSelectionSetting extends RegistryListSetting<Block> {
    private final Supplier<ChoiceSetting> mode;
    private final Supplier<CharSequence> fullBlockMode;

    
    public AutoTrapBlockSelectionSetting(CharSequence label, Supplier<Registry<Block>> registry, Supplier<ChoiceSetting> mode, Supplier<CharSequence> fullBlockMode) {
        super(label, registry);
        this.mode = mode;
        this.fullBlockMode = fullBlockMode;
        setEntrySelected(Blocks.OBSIDIAN, true);
    }

    @Override
    public Function<Block, String> getEntryLabel() {
        return block -> new ItemStack(block.asItem()).getHoverName().getString();
    }

    @Override
    public Predicate<Block> getEntryFilter() {
        return block -> block.asItem() instanceof BlockItem
                && block.defaultBlockState().isCollisionShapeFullBlock(EmptyBlockGetter.INSTANCE, BlockPos.ZERO);
    }

    @Override
    public boolean isVisible() {
        return mode.get().isSelected(fullBlockMode.get());
    }
}
