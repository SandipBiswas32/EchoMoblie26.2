package dev.dov.hack.echo.client.event.render;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.dov.hack.echo.client.event.Event;
import dev.dov.hack.echo.client.event.input.KeybindingEvent;
import dev.dov.hack.echo.client.render.world.WorldRenderContext;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import org.joml.Matrix4f;

public class WorldRenderEvent extends Event {
    private final PoseStack matrices;
    private final float tickProgress;
    private final float dynamicDeltaTicks;
    private final Camera camera;
    private final GameRenderer gameRenderer;
    private final Matrix4f projectionMatrix;
    private final Matrix4f viewMatrix;
    private final LevelRenderer worldRenderer;
    private final WorldRenderContext renderContext;

    
    public WorldRenderEvent(PoseStack matrices, float tickProgress, float dynamicDeltaTicks, Camera camera, GameRenderer gameRenderer, Matrix4f projectionMatrix, Matrix4f viewMatrix, LevelRenderer worldRenderer, WorldRenderContext renderContext) {
        this.matrices = matrices;
        this.tickProgress = tickProgress;
        KeybindingEvent.getInputSentinel();
        this.dynamicDeltaTicks = dynamicDeltaTicks;
        this.camera = camera;
        this.gameRenderer = gameRenderer;
        this.projectionMatrix = projectionMatrix;
        this.viewMatrix = viewMatrix;
        this.worldRenderer = worldRenderer;
        this.renderContext = renderContext;
        if (Event.getEventCounter() != 0) {
            KeybindingEvent.setInputSentinel(new String[1]);
        }
    }

    
    public PoseStack getMatrices() { return matrices; }
    
    public float getTickProgress() { return tickProgress; }
    
    public float getDynamicDeltaTicks() { return dynamicDeltaTicks; }
    
    public Camera getCamera() { return camera; }
    
    public GameRenderer getGameRenderer() { return gameRenderer; }
    
    public Matrix4f getProjectionMatrix() { return projectionMatrix; }
    
    public Matrix4f getViewMatrix() { return viewMatrix; }
    
    public LevelRenderer getWorldRenderer() { return worldRenderer; }
    
    public WorldRenderContext getRenderContext() { return renderContext; }
}
