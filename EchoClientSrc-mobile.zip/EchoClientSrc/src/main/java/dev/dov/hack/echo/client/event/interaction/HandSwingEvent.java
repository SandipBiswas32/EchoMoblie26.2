package dev.dov.hack.echo.client.event.interaction;

import dev.dov.hack.echo.client.event.Event;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;

public class HandSwingEvent extends Event {
    private final Player player;
    private final InteractionHand hand;

    
    public HandSwingEvent(Player player, InteractionHand hand) {
        this.player = player;
        this.hand = hand;
    }

    
    public Player getPlayer() {
        return player;
    }

    
    public InteractionHand getHand() {
        return hand;
    }
}
