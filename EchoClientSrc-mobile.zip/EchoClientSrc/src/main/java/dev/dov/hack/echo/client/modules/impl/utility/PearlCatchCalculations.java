package dev.dov.hack.echo.client.modules.impl.utility;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

public final class PearlCatchCalculations {
    private PearlCatchCalculations() {
    }

    
    public static float aimSpeed(float targetYaw, float targetPitch, float playerYaw, float playerPitch, int throwTick, int playerAge) {
        float yawDifference = Math.abs(Mth.wrapDegrees(targetYaw - playerYaw));
        float pitchDifference = Math.abs(targetPitch - playerPitch);
        float largestDifference = Math.max(yawDifference, pitchDifference);
        float availableSeconds = Math.max(1, throwTick - playerAge - 1) * 0.05F;
        return Mth.clamp(largestDifference / availableSeconds, 40.0F, 300.0F);
    }

    
    public static Vec3 origin(Vec3 capturedOrigin, Vec3 playerPosition) {
        return capturedOrigin != null ? capturedOrigin : playerPosition;
    }

    
    public static Vec3 restoredVelocity(Vec3 savedVelocity, boolean suppressVertical) {
        return new Vec3(savedVelocity.x, suppressVertical ? 0.0 : savedVelocity.y, savedVelocity.z);
    }

    
    public static void usePendingOffhandWindCharge(Minecraft client) {
        if (client.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))
                && !client.player.getCooldowns().isOnCooldown(new ItemStack(Items.WIND_CHARGE))
                && client.player.getOffhandItem().is(Items.WIND_CHARGE)) {
            client.gameMode.useItem(client.player, InteractionHand.OFF_HAND);
        }
    }
}
