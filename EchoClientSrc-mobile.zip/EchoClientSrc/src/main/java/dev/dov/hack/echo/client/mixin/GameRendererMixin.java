package dev.dov.hack.echo.client.mixin;
import dev.dov.hack.echo.client.platform.Platform;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.event.render.WorldRenderEvent;
import dev.dov.hack.echo.client.gfx.FullscreenEffects;
import dev.dov.hack.echo.client.render.bridge.MinecraftRenderState;
import dev.dov.hack.echo.client.render.world.WorldRenderContext;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.fog.FogRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin implements Platform.RenderLoop {
    @Shadow @Final private FogRenderer fogRenderer;
    @Shadow @Final private GuiRenderer guiRenderer;
    @Shadow protected abstract void bobView(PoseStack matrices, float tickProgress);
    @Shadow protected abstract void bobHurt(PoseStack matrices, float tickProgress);

    @Inject(method = "renderLevel(Lnet/minecraft/client/DeltaTracker;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiling/ProfilerFiller;popPush(Ljava/lang/String;)V", ordinal = 0))
    private void captureProjection(DeltaTracker ticks, CallbackInfo callback, @Local(ordinal = 0) Matrix4f projection) {
        FullscreenEffects.captureProjection(projection);
    }

    @Inject(method = "renderLevel(Lnet/minecraft/client/DeltaTracker;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiling/ProfilerFiller;popPush(Ljava/lang/String;)V", ordinal = 2))
    private void renderWorldOverlays(DeltaTracker ticks, CallbackInfo callback, @Local(ordinal = 0) float tickProgress, @Local(ordinal = 0) Matrix4f projection, @Local(ordinal = 1) Matrix4f view, @Local PoseStack matrices) {
        if (!EchoClient.eventsDisabled && EchoClient.worldRenderer != null && EchoClient.commandEncoder != null) {
            Minecraft client = Minecraft.getInstance();
            Camera camera = MinecraftRenderState.getCamera(Minecraft.getInstance());
            RenderSystem.getModelViewStack().pushMatrix().mul(view);
            PoseStack viewEffects = new PoseStack();
            echo$applyViewEffects(viewEffects, tickProgress);
            RenderSystem.getModelViewStack().mul(viewEffects.last().pose().invert());
            WorldRenderContext context = EchoClient.worldRenderer;
            context.setMatrices(view, projection);
            context.beginFrame();
            new WorldRenderEvent(matrices, tickProgress, ticks.getGameTimeDeltaTicks(), camera, (GameRenderer) (Object) this, projection, view, client.levelRenderer, context).post();
            context.flush();
            RenderSystem.getModelViewStack().popMatrix();
        }
    }

    @Inject(method = "render(Lnet/minecraft/client/DeltaTracker;Z)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/LevelRenderer;doEntityOutline()V"))
    private void prepareEntityOutlines(CallbackInfo callback) {
        ((Platform.SceneBuffer) Minecraft.getInstance().levelRenderer).updateOutlineFramebufferCancellation();
    }

    @Inject(method = "render(Lnet/minecraft/client/DeltaTracker;Z)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/render/GuiRenderer;render(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V"))
    private void beginMainGuiPass(CallbackInfo callback) {
        ((Platform.GuiLoop) guiRenderer).setMainGuiPass(true);
    }

    @Inject(method = "render(Lnet/minecraft/client/DeltaTracker;Z)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/render/GuiRenderer;render(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V", shift = At.Shift.AFTER))
    private void endMainGuiPass(CallbackInfo callback) {
        ((Platform.GuiLoop) guiRenderer).setMainGuiPass(false);
    }

    @Inject(method = "resize", at = @At("HEAD"), cancellable = true)
    private void deferResizeWhileOverlayPresent(int width, int height, CallbackInfo callback) {
        if (Minecraft.getInstance() != null && MinecraftRenderState.getOverlay() != null) {
            callback.cancel();
        }
    }

    @Override
    public void renderGuiWithoutFog() {
        guiRenderer.render(fogRenderer.getBuffer(FogRenderer.FogMode.NONE));
    }

    @Unique
    private void echo$applyViewEffects(PoseStack matrices, float tickProgress) {
        bobHurt(matrices, tickProgress);
        if (Minecraft.getInstance().options.bobView().get()) {
            bobView(matrices, tickProgress);
        }
    }
}
