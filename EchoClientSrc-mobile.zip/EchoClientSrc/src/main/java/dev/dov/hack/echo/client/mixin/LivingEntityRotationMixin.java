package dev.dov.hack.echo.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.event.movement.RotationContext;
import dev.dov.hack.echo.client.event.movement.RotationEvent;
import dev.dov.hack.echo.client.modules.impl.render.SwingSpeed;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityRotationMixin extends Entity {
    @Unique private boolean echo$rotationOverridden;
    @Unique private float echo$savedYaw;
    @Unique private float echo$savedPitch;

    public LivingEntityRotationMixin(EntityType<?> type, Level world) {
        super(type, world);
    }

    @Inject(method = "aiStep", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;applyInput()V", shift = At.Shift.AFTER))
    private void applyMovementRotation(CallbackInfo callback) {
        if (!EchoClient.eventsDisabled && (Object) this == Minecraft.getInstance().player) {
            RotationEvent rotation = RotationEvent.dispatch(RotationContext.MOVEMENT, getYRot(), getXRot());
            echo$rotationOverridden = rotation.getYaw() != getYRot() || rotation.getPitch() != getXRot();
            if (echo$rotationOverridden) {
                echo$savedYaw = getYRot();
                echo$savedPitch = getXRot();
                setYRot(rotation.getYaw());
                setXRot(rotation.getPitch());
            }
        }
    }

    @Inject(method = "aiStep", at = @At("RETURN"))
    private void restoreMovementRotation(CallbackInfo callback) {
        if (echo$rotationOverridden) {
            echo$rotationOverridden = false;
            setYRot(echo$savedYaw);
            setXRot(echo$savedPitch);
        }
    }

    @ModifyExpressionValue(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getYRot()F", ordinal = 0))
    private float modifyFirstTickYaw(float original) {
        return echo$resolveBodyYaw(original);
    }

    @ModifyExpressionValue(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getYRot()F", ordinal = 1))
    private float modifySecondTickYaw(float original) {
        return echo$resolveBodyYaw(original);
    }

    @ModifyExpressionValue(method = "tickHeadTurn", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getYRot()F"))
    private float modifyHeadTurnYaw(float original) {
        return echo$resolveBodyYaw(original);
    }

    @Unique
    private float echo$resolveBodyYaw(float original) {
        return (Object) this != Minecraft.getInstance().player ? original
                : RotationEvent.dispatch(RotationContext.BODY, original, Minecraft.getInstance().player.getXRot()).getYaw();
    }

    @Inject(method = "getCurrentSwingDuration", at = @At("HEAD"), cancellable = true)
    private void modifyHandSwingDuration(CallbackInfoReturnable<Integer> callback) {
        if (!EchoClient.eventsDisabled && EchoClient.ModuleManager != null && (Object) this == Minecraft.getInstance().player) {
            SwingSpeed swing = (SwingSpeed) EchoClient.ModuleManager.findFeature(SwingSpeed.class);
            if (swing != null && swing.isEnabled()) {
                callback.setReturnValue(SwingSpeed.swingSpeed.getValue());
            }
        }
    }
}
