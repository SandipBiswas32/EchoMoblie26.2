package dev.dov.hack.echo.client.modules.impl.combat;

import dev.dov.hack.echo.client.event.Subscribe;
import dev.dov.hack.echo.client.event.input.HandleInputEvent;
import dev.dov.hack.echo.client.event.interaction.AttackAttemptEvent;
import dev.dov.hack.echo.client.modules.ModuleCategory;
import dev.dov.hack.echo.client.modules.Module;
import dev.dov.hack.echo.client.modules.ModuleInfo;
import dev.dov.hack.echo.client.utils.strings.SegmentedText;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import dev.dov.hack.echo.client.utils.items.InventoryItems;

public class CrystalOptimizer extends Module {
    private EndCrystal trackedCrystal;

    public CrystalOptimizer() {
        super(new ModuleInfo(dev.dov.hack.echo.client.init.CatalogText.literal("Crystal Optimizer"), dev.dov.hack.echo.client.init.CatalogText.literal("Optimizes crystal speeds"), dev.dov.hack.echo.client.modules.ModuleCategory.COMBAT));
    }

    @Subscribe
    public void onAttackAttempt(AttackAttemptEvent event) {
        if (isOutsideWorld() || client.hitResult == null
                || client.hitResult.getType() != HitResult.Type.ENTITY) {
            return;
        }
        if (!(client.hitResult instanceof EntityHitResult hit)
                || !(hit.getEntity() instanceof EndCrystal crystal)) {
            return;
        }
        MobEffectInstance weakness = client.player.getEffect(MobEffects.WEAKNESS);
        MobEffectInstance strength = client.player.getEffect(MobEffects.STRENGTH);
        boolean canBreakCrystal = weakness == null
                || strength != null && strength.getAmplifier() > weakness.getAmplifier()
                || InventoryItems.holdsPickaxe() || InventoryItems.holdsSword();
        if (canBreakCrystal) {
            trackedCrystal = crystal;
        }
    }

    @Subscribe
    private void onInputHandled(HandleInputEvent.Post event) {
        if (trackedCrystal == null) {
            return;
        }
        if (!trackedCrystal.isRemoved()) {
            trackedCrystal.setRemoved(Entity.RemovalReason.KILLED);
            trackedCrystal.onClientRemoval();
        }
        trackedCrystal = null;
    }

    @Override
    public void onDisable() {
        trackedCrystal = null;
        super.onDisable();
    }

}
