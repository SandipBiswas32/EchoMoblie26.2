package dev.dov.hack.echo.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.event.render.FireOverlayEvent;
import dev.dov.hack.echo.client.event.render.FloatingItemOverlayEvent;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ScreenEffectRenderer.class)
public class InGameOverlayRendererMixin {
    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true)
    private static void onRenderFireOverlayHead(PoseStack matrices, MultiBufferSource vertices, TextureAtlasSprite fireSprite, CallbackInfo callback) {
        if (!EchoClient.eventsDisabled) {
            FireOverlayEvent event = new FireOverlayEvent();
            event.post();
            if (event.cancelled) {
                callback.cancel();
            }
        }
    }

    @Inject(method = "renderItemActivationAnimation", at = @At("HEAD"), cancellable = true)
    public void onRenderFloatingItemHead(PoseStack matrices, float tickProgress, SubmitNodeCollector queue, CallbackInfo callback) {
        if (!EchoClient.eventsDisabled) {
            FloatingItemOverlayEvent event = new FloatingItemOverlayEvent();
            event.post();
            if (event.cancelled) {
                callback.cancel();
            }
        }
    }
}
